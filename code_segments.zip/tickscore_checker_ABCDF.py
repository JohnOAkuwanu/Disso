import pandas as pd
import numpy as np
from get_all_tickers.get_tickers import *
import yfinance as yf
from scipy.stats import norm


def SharpeRatio(rt_df, bncmrk=0.02):
    SR = np.sqrt(len(rt_df))*(rt_df['NetWorth'].mean() - bncmrk) / rt_df['NetWorth'].std()
    return SR

def get_metrics(df, digits=3, periods = 0):
    risk_free_return = 0
    df['return'] = df['NetWorth'] / df['NetWorth'][0]
    max_drawdown = 1.0 - min(df['return'].values)
    df['return_pct'] = df['NetWorth'].pct_change(1)
    sharpe = (df['NetWorth'].mean() - risk_free_return) / df['NetWorth'].std()
    sharpe *= periods ** 0.5 #annualize
    sharpe /= 100
    #sharpe = np.mean(ret) / np.std(ret)
    return round(df['NetWorth'][-1]/df['NetWorth'][0], digits), round(sharpe, digits), round(max_drawdown * 100, digits-2)

df_health = pd.read_csv('tick_score_health.csv')
df_tech = pd.read_csv('tick_score_tech.csv')
df_durable = pd.read_csv('tick_score_durable.csv')
df_nondurable = pd.read_csv('tick_score_nondurable.csv')
df_capital = pd.read_csv('tick_score_capital.csv')
df_transport = pd.read_csv('tick_score_transport.csv')
df_util = pd.read_csv('tick_score_util.csv')
df_services = pd.read_csv('tick_score_services.csv')
df_energy = pd.read_csv('tick_score_energy.csv')
df_finance = pd.read_csv('tick_score_finance.csv')
df_basics = pd.read_csv('tick_score_basics.csv')


frames = [df_finance, df_capital, df_durable, df_energy, df_health, df_nondurable, df_services, df_tech, df_services, df_util, df_basics]
df = pd.concat(frames)
df = df.drop_duplicates(subset=['Unnamed: 0'], keep='last')
df = df.set_index("Unnamed: 0")

percentile = np.percentile(df['Score'], 90)
mu, std = norm.fit(df['Score'])



df_metrics = pd.DataFrame(index=df.columns, columns=['A', 'B', 'C', 'D', 'F'])



aplus = df[df['Score'] > mu + (2*std)]
print(aplus.mean(axis=0)) 
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][0] = output
    else:
        df_metrics.loc[col][0] = '-'   
portfolio = list(aplus.index)
portfolio.sort()      


aplus = df[df['Score'] > mu + std]
aplus = aplus[aplus['Score'] < mu + (2*std)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][1] = output
    else:
        df_metrics.loc[col][1] = '-'


aplus = df[df['Score'] > mu]
aplus = aplus[aplus['Score'] < mu + std]


for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][2] = output
    else:
        df_metrics.loc[col][2] = '-'

aplus = df[df['Score'] > mu - std]
aplus = aplus[aplus['Score'] < mu]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][3] = output
    else:
        df_metrics.loc[col][3] = '-'

aplus = df[df['Score'] > mu - (2*std)]
aplus = aplus[aplus['Score'] < mu - std]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][4] = output
    else:
        df_metrics.loc[col][4] = '-'

        
        
print(df_metrics)

data = yf.download(portfolio, start = "2016-01-01", end = "2020-12-30", threads = False)
data = data.loc[:,('Adj Close', slice(None))]
data.columns = portfolio
returns = data[portfolio].pct_change().dropna()


d_data = data.mean(axis=1)
d_data = pd.DataFrame(d_data)
d_data.columns = ["NetWorth"]
print(d_data)
print(get_metrics(d_data, digits=3, periods = 0))

print(SharpeRatio(d_data))