import pandas as pd
import numpy as np
from get_all_tickers.get_tickers import *
import yfinance as yf
from scipy.stats import norm
from pandas_datareader import data as pdr


def SharpeRatio(rt_df, bncmrk=0.02):
    SR = np.sqrt(len(rt_df))*(rt_df['NetWorth'].mean() - bncmrk) / rt_df['NetWorth'].std()
    return SR

def get_metrics(df, digits=3, periods = 0):
    risk_free_return = 0
    df['return'] = df['NetWorth'] / df['NetWorth'][0]
    max_drawdown = 1.0 - min(df['return'].values)
    df['return_pct'] = df['NetWorth'].pct_change(1)
    sharpe = (df['NetWorth'].mean() - risk_free_return) / df['NetWorth'].std()
    sharpe *= periods ** 0.5 #annualize
    sharpe /= 100
    #sharpe = np.mean(ret) / np.std(ret)
    return round(df['NetWorth'][-1]/df['NetWorth'][0], digits), round(sharpe, digits), round(max_drawdown * 100, digits-2)

def port_metrics(portfolio, df_portmetrics, col = 0):
    #data = pdr.get_data_yahoo(portfolio, start = "2019-01-01", end = "2021-01-04")
    print(portfolio)
    try:
        data = yf.download(portfolio, start = "2020-01-01", end = "2021-01-04", threads = False)
    except:
        return df_portmetrics
    if len(portfolio) < 2:
        data = data.loc[:,('Adj Close')]
        data = pd.DataFrame(data)
        data.columns = ['NetWorth']
        sharpe = SharpeRatio(data)
        sharpe /= 100
        profit, sharp, max_dd = get_metrics(data, digits=3, periods = len(data))
    else:
        #data = data.loc[:,('Adj Close', slice(None))]
        data = data.loc[:,('Adj Close', slice(None))]
        data.columns = portfolio
        d_data = []
        for i in range (0, len(data)-1):
            lst = [float(item) for item in data.iloc[i] if item == item and item != "-"]
            if len(lst) > 0:
                output = sum(lst) / len(lst)
                d_data.append(output)
            else:continue
        
        d_data = pd.Series(d_data, index = data.index[-252:])
        print(d_data)
        d_data = pd.DataFrame(d_data)
        d_data.columns = ["NetWorth"]
        print(d_data)
        sharpe = SharpeRatio(d_data)
        sharpe /= 100
        profit, sharp, max_dd = get_metrics(d_data, digits=3, periods = len(data))

    df_portmetrics.loc["Mean Sharpe Ratio"][col] = sharpe
    df_portmetrics.loc["Mean Profit Factor"][col] = profit
    df_portmetrics.loc["Mean Max Drawdown"][col] = max_dd

    return df_portmetrics

df_health = pd.read_csv('2007-2010/tick_score_Health Care.csv')
df_tech = pd.read_csv('2007-2010/tick_score_Technology.csv')
df_durable = pd.read_csv('2007-2010/tick_score_Consumer Durables.csv')
df_nondurable = pd.read_csv('2007-2010/tick_score_Consumer Non-Durables.csv')
df_capital = pd.read_csv('2007-2010/tick_score_Capital Goods.csv')
df_transport = pd.read_csv('2007-2010/tick_score_Transportation.csv')
df_util = pd.read_csv('2007-2010/tick_score_Public Utilities.csv')
df_services = pd.read_csv('2007-2010/tick_score_Consumer Services.csv')
df_energy = pd.read_csv('2007-2010/tick_score_Energy.csv')
df_finance = pd.read_csv('2007-2010/tick_score_Finance.csv')
df_basics = pd.read_csv('2007-2010/tick_score_Basic Industries.csv')

frames = [df_finance, df_capital, df_durable, df_energy, df_health, df_nondurable, df_services, df_tech, df_util, df_basics]
df = pd.concat(frames)
df = df.set_index("Unnamed: 0")
print(df)
#df = df.drop_duplicates(subset=df.index, keep='last')
#, index_col=0

#df = df[df.index.duplicated(keep='first')]

'''
df_sectors = pd.DataFrame(index=['1 day', '1 week', '1 month', '3 months', '6 months', '1 year'], columns=['Finance', 'Capital', 'Durable', 'Energy', 'Health', 'Non-Durable', 'Services', 'Tech', 'Utilities', 'Basics'])
for i in range (0, len(frames)):
    local_df = frames[i]
    percentile = np.percentile(local_df['Score'], 90)
    local_df = local_df[local_df['Score'] >= percentile] 
    for col in df_sectors.index:
        lst = [float(item) for item in local_df[col] if item == item and item != "-"]
        if len(lst) > 0:
            output = sum(lst) / len(lst)
        df_sectors.loc[col][i] = output
    

print(df_sectors)
'''
        
#print(df)
percentile = np.percentile(df['Score'], 90)
mu, std = norm.fit(df['Score'])
roc = std / 3


df_metrics = pd.DataFrame(index=df.columns, columns=['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-', 'F'])
df_portmetrics = pd.DataFrame(index=["Mean Sharpe Ratio", "Mean Profit Factor", "Mean Max Drawdown"], columns=['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-', 'A+ to A-', 'B+ to B-', 'C+ to C-', 'D+ to D-'])



aplus = df[df['Score'] > percentile]
print(aplus)
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][0] = output
    else:
        df_metrics.loc[col][0] = '-'   
all_a = list(aplus.index)
port_aplus = list(aplus.index)


aplus = df[df['Score'] > percentile - (roc)]
aplus = aplus[aplus['Score'] < percentile]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][1] = output
    else:
        df_metrics.loc[col][1] = '-'
all_a.extend(list(aplus.index))
port_a = list(aplus.index)


aplus = df[df['Score'] > percentile - (roc*2)]
aplus = aplus[aplus['Score'] < percentile - (roc)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][2] = output
    else:
        df_metrics.loc[col][2] = '-'
all_a.extend(list(aplus.index))
port_aminus = list(aplus.index)

aplus = df[df['Score'] > percentile - (roc*3)]
aplus = aplus[aplus['Score'] < percentile - (roc*2)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][3] = output
    else:
        df_metrics.loc[col][3] = '-'
all_b = list(aplus.index)
port_bplus = list(aplus.index)


aplus = df[df['Score'] > percentile - (roc*4)]
aplus = aplus[aplus['Score'] < percentile - (roc*3)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][4] = output
    else:
        df_metrics.loc[col][4] = '-'
all_b.extend(list(aplus.index))
port_b = list(aplus.index)

aplus = df[df['Score'] > percentile - (roc*5)]
aplus = aplus[aplus['Score'] < percentile - (roc*4)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][5] = output
    else:
        df_metrics.loc[col][5] = '-'
all_b.extend(list(aplus.index))
port_bminus = list(aplus.index)
    
aplus = df[df['Score'] > percentile - (roc*6)]
aplus = aplus[aplus['Score'] < percentile - (roc*5)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][6] = output
    else:
        df_metrics.loc[col][6] = '-'
all_c = list(aplus.index)
port_cplus = list(aplus.index)


aplus = df[df['Score'] > percentile - (roc*7)]
aplus = aplus[aplus['Score'] < percentile - (roc*6)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][7] = output
    else:
        df_metrics.loc[col][7] = '-'
all_c.extend(list(aplus.index))
port_c = list(aplus.index)

aplus = df[df['Score'] > percentile - (roc*8)]
aplus = aplus[aplus['Score'] < percentile - (roc*7)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][8] = output
    else:
        df_metrics.loc[col][8] = '-'
all_c.extend(list(aplus.index))
port_cminus = list(aplus.index)

        
aplus = df[df['Score'] > percentile - (roc*9)]
aplus = aplus[aplus['Score'] < percentile - (roc*8)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][9] = output
    else:
        df_metrics.loc[col][9] = '-'
all_d = list(aplus.index)
port_dplus = list(aplus.index)

aplus = df[df['Score'] > percentile - (roc*10)]
aplus = aplus[aplus['Score'] < percentile - (roc*9)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][10] = output
    else:
        df_metrics.loc[col][10] = '-'
all_d.extend(list(aplus.index))
port_d = list(aplus.index)

aplus = df[df['Score'] > percentile - (roc*11)]
aplus = aplus[aplus['Score'] < percentile - (roc*10)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][11] = output
    else:
        df_metrics.loc[col][11] = '-'
all_d.extend(list(aplus.index))
port_dminus = list(aplus.index)

aplus = df[df['Score'] < percentile - (roc*11)]
for col in aplus.columns:
    lst = [float(item) for item in aplus[col] if item == item and item != "-"]
    if len(lst) > 0:
        output = sum(lst) / len(lst)
        df_metrics.loc[col][12] = output
    else:
        df_metrics.loc[col][12] = '-'
        
        
df_portmetrics = port_metrics(port_aplus, df_portmetrics, col = 0)
df_portmetrics = port_metrics(port_a, df_portmetrics, col = 1)
df_portmetrics = port_metrics(port_aminus, df_portmetrics, col = 2)

df_portmetrics = port_metrics(port_bplus, df_portmetrics, col = 3)
df_portmetrics = port_metrics(port_b, df_portmetrics, col = 4)
df_portmetrics = port_metrics(port_bminus, df_portmetrics, col = 5)

df_portmetrics = port_metrics(port_cplus, df_portmetrics, col = 6)
df_portmetrics = port_metrics(port_c, df_portmetrics, col = 7)
df_portmetrics = port_metrics(port_cminus, df_portmetrics, col = 8)

df_portmetrics = port_metrics(port_dplus, df_portmetrics, col = 9)
df_portmetrics = port_metrics(port_d, df_portmetrics, col = 10)
df_portmetrics = port_metrics(port_dminus, df_portmetrics, col = 11)

df_portmetrics = port_metrics(all_a, df_portmetrics, col = 12)
df_portmetrics = port_metrics(all_b, df_portmetrics, col = 13)
df_portmetrics = port_metrics(all_c, df_portmetrics, col = 14)
df_portmetrics = port_metrics(all_d, df_portmetrics, col = 15)

print(df_portmetrics)
df_portmetrics.to_csv("grade_metrics_a_2010.csv")
