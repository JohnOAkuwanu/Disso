import pandas as pd
import matplotlib.pyplot as plt
import math
import datetime as dt
import statistics as stats
import numpy as np
import yfinance as yf
from get_all_tickers import get_tickers as gt
from get_all_tickers.get_tickers import *


def ebitda_growth(ebitb, ebita):
    current_yr = ebita
    last_yr = ebitb
    
    percent = ((current_yr - last_yr)/last_yr)*100
    percent = round(percent,3)
    return(percent)

def ebitda_margin(ebitda, total_sales):
    percent = ((ebitda)/total_sales)*100
    percent = round(percent,3)
    return(percent)

def pat_margin(net_inc, net_sales):
    percent = ((net_inc)/net_sales)*100
    percent = round(percent,3)
    return(percent)

def roce(EBIT, total_assets, current_liab):
    ROCE = (EBIT / (total_assets - current_liab))*100
    percent = round(ROCE,3)
    return(percent)

def interest_cov(ebit, interest_exp):
    percent = (ebit / interest_exp)*100
    percent = round(percent,3)
    return(percent)

def debt_to_equity(liab, share_equity):
    percent = (liab / share_equity)*100
    percent = round(percent,3)
    return(percent)

def debt_to_asset(total_debt, assets):
    percent = (total_debt / assets)*100
    percent = round(percent,3)
    return(percent)

def cf_margin(OCF, sales):
    percent = (OCF / sales)*100
    percent = round(percent,3)
    return(percent)

def calculate_grade(smoothedList, lessThan = False):
    stdev = np.std(smoothedList, axis = 0) / 3
    percentile = np.percentile(smoothedList, 90)
    #If a metric is better, lower the value set lessThan to True
    if lessThan == True:
        percentile = np.percentile(smoothedList, 10)
    
    return percentile, stdev

def getAverage(df, lessThan = False):
    data_return = []
    for col in df:
        if col == None:
            continue
        metrics = df[col]
        try:metrics = metrics[metrics != None]
        except:pass
        try:metrics = metrics[metrics != '-']
        except:pass
        try:metrics = metrics[~np.isnan(metrics)].tolist()
        except:pass
        elements = np.array(metrics)
        try:
            mean = np.mean(elements, axis=0)
            sd = np.std(elements, axis=0)

            for i in range(2):
                smoothedList = [x for x in metrics if (x > mean - 2 * sd)]
                smoothedList = [x for x in smoothedList if (x < mean + 2 * sd)]

                mean = np.mean(smoothedList, axis=0)
                sd = np.std(smoothedList, axis=0)

            stdev = np.std(smoothedList, axis = 0) / 3
            start = np.percentile(smoothedList, 90)
            smoothedAvg =  np.percentile(smoothedList, 50)
        
            if lessThan == True:
                start = np.percentile(smoothedList, 10)
        
            data_return.append([col, smoothedAvg, start, stdev, smoothedList])
        except:pass
        
    return data_return

SECTORS_LIST = set(['Capital Goods', 'Health Care', 'Consumer Non-Durables', 'Consumer Durables', 'Energy', 'Technology', 'Basic Industries', 'Finance', 'Consumer Services', 'Public Utilities', 'Transportation'])

for sector in SECTORS_LIST:
    stocks = get_tickers_filtered(mktcap_min=1000, mktcap_max=None, sectors=sector)
    print(sector)
    columns = ['ROE', 'ROA', 'Price-to-Book', 'eps', 'Debt_Asset', 'Debt_Equity','PAT_Margin', 'EBITDA_Margin', 'ROCE', 'Investments', 'ROI']
    df = pd.DataFrame(index=stocks, columns=columns)
    df = df.fillna(-1)

    for ticker in stocks:
        try:
            balance_sheet = pd.read_csv(f"all_stocks\{ticker}_balancesheet_2005_2020.csv", index_col="date").loc[2015]
            if len(balance_sheet) > 1:
                balance_sheet = balance_sheet.iloc[0].combine_first(balance_sheet.iloc[1])
            if balance_sheet == None:
                raise Exception
        except:pass

        try:
            ratios_df = pd.read_csv(f"all_stocks\{ticker}_ratios_2005_2020.csv", index_col="date").loc[2015]
            if len(ratios_df) > 1:
                ratios_df = ratios_df.iloc[0].combine_first(ratios_df.iloc[1])
            if ratios_df == None:
                raise Exception
        except:pass
        
        try:
            income_df = pd.read_csv(f"all_stocks\{ticker}_income_2005_2020.csv", index_col="date").loc[2015]
            if len(income_df) > 1:
                income_df = income_df.iloc[0].combine_first(income_df.iloc[1])
            if income_df == None:
                    raise Exception
        except:pass
        
        try:
            cashflow_df = pd.read_csv(f"all_stocks\{ticker}_cashflow_2005_2020.csv", index_col="date").loc[2015]
            if len(cashflow_df) > 1:
                cashflow_df = cashflow_df.iloc[0].combine_first(cashflow_df.iloc[1])
            if cashflow_df == None:
                raise Exception
        except:pass
            
        #########################################################

        try:
            total_assets = balance_sheet["total_assets"]
            if total_assets == None:
                raise Exception
        except:total_assets = '-'
        
    
        try:
            total_current_liab = balance_sheet['total_current_liabilities']
            if total_current_liab == None:
                raise Exception
        except:total_current_liab = '-'
        
        try:
            price_to_book = ratios_df['book_value_per_share']
            if price_to_book == None:
                raise Exception
        except:price_to_book = '-'
        
        try:
            eps = income_df["eps__earnings_per_share"]
            if eps == None:
                raise Exception
        except:
            try:
                eps = income_df["basic_eps"]
                if eps == None:
                    raise Exception
            except:eps = '-'

        try:
            ROA = ratios_df["roa__return_on_assets"]
            if ROA == None:
                raise Exception
        except:ROA = '-'
        
        try:
            ROI = ratios_df["roi__return_on_investment"]
            if ROI == None:
                raise Exception
        except:ROI = '-'

                                
        try:
            roe = ratios_df["roe__return_on_equity"]
            if roe == None:
                raise Exception
        except:roe = '-'
        
        try:
            investments = balance_sheet["longterm_investments"]
            if investments == None:
                raise Exception
        except:
            investments = '-'
            
        try:
            OCF = income_df["cash_flow_from_operating_activities"]
            if OCF == None:
                raise Exception
        except:OCF = '-'
                

        try:
            EBIT = income_df["ebitda"]
            if EBIT == None:
                raise Exception
        except:EBIT = '-'
            

        try:
            gross_profit = income_df["gross_profit"]  
            if gross_profit == None:
                raise Exception
        except:gross_profit = '-'
        

        try:
            revenue_cost = income_df['cost_of_goods_sold']
            if revenue_cost == None:
                raise Exception
        except:revenue_cost='-'
        

        try:
            total_revenue = income_df["revenue"]
            if total_revenue == None:
                raise Exception
        except:
            total_revenue = '-'
        
        
        try:
            CF_Margin = cf_margin(OCF, total_revenue)
        except:
            CF_Margin = '-'
        
        try:
            EBITDA_Margin = ratios_df["ebitda_margin"]
        except:
            EBITDA_Margin = '-'
        
        try:
            ROCE = roce(EBIT, total_assets, total_current_liab)
        except:ROCE = '-'
        try:
            PAT_Margin = ratios_df["net_profit_margin"]
        except:
            PAT_Margin = '-'
        
        try:
            Debt_Equity = ratios_df["debt_to_equity_ratio"]
        except: Debt_Equity = '-'
        
        try:
            Debt_Asset = ratios_df["longterm_debt_to_capital"]
        except: Debt_Asset = '-'
        
                
                
        df.loc[ticker] = [roe, ROA, price_to_book, eps, Debt_Asset, Debt_Equity, PAT_Margin, EBITDA_Margin, ROCE, investments, ROI]

    #col, smoothedAvg, start, stdev, smoothedList
    df = df.drop_duplicates(subset=['ROE', 'ROA', 'Price-to-Book', 'eps', 'Debt_Asset', 'Debt_Equity','PAT_Margin', 'EBITDA_Margin', 'ROCE', 'Investments', 'ROI'], keep='first')
    df.to_csv(f"portfolio_{sector}_2010.csv")


    df_sector = pd.DataFrame(getAverage(df))
    df_sector = df_sector.set_index(0)

    df_sector.columns = ['smoothedAvg', 'start', 'stdev', 'smoothedList']
    df_sector.to_csv(f"large_sector_out_{sector}_2010.csv")