from operator import index
import pandas as pd
import numpy as np
from get_all_tickers.get_tickers import *
import yfinance as yf
from fbprophet import Prophet
import datetime as dt
from fbprophet.diagnostics import cross_validation, performance_metrics
from fbprophet.plot import plot_cross_validation_metric
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.svm import SVR

start_date = "2010-01-01"
end_date = "2021-01-01"

def ebitda_margin(ebitda, total_sales):
    percent = ((ebitda)/total_sales)*100
    percent = round(percent,3)
    return(percent)

def roce(EBIT, total_assets, current_liab):
    ROCE = (EBIT / (total_assets - current_liab))*100
    percent = round(ROCE,3)
    return(percent)

def calculate_grade(smoothedList, lessThan = False):
    stdev = np.std(smoothedList, axis = 0) / 3
    percentile = np.percentile(smoothedList, 90)

    #If a metric is better, lower the value set lessThan to True
    if lessThan == True:
        percentile = np.percentile(smoothedList, 10)
    
    return percentile, stdev

def diagnose_model(horizon_days, model):
    """
    Diagnose the model
    Inputs:
    horizon_days - is the number of days to use when testing the model
    model - is the Phropet model
    """

    horizon = str(horizon_days) + ' days'

    df_cross_validation = cross_validation(model, horizon=horizon)

    df_performance = performance_metrics(df_cross_validation)
    fig = plot_cross_validation_metric(df_performance, metric='mape')
    plt.plot(fig)
    print(df_performance)
    return {'df_cross_validation': df_cross_validation, 'df_performance': df_performance}

def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

SECTORS_LIST = set(['Capital Goods', 'Health Care', 'Energy', 'Consumer Non-Durables', 'Consumer Durables', 'Technology', 'Basic Industries', 'Finance', 'Consumer Services', 'Public Utilities', 'Transportation'])

for sector in SECTORS_LIST:
    stocks = get_tickers_filtered(mktcap_min=1000, mktcap_max=None, sectors=sector)
    sector_data = pd.read_csv(f"large_sector_out_{sector}_2010.csv", index_col=0)

    portfolio = pd.read_csv(f"portfolio_{sector}_2010.csv", index_col=0)

    df_sum = pd.DataFrame(index=stocks, columns=['Score'])
    df_sum = df_sum.fillna(-1)

    for tick in stocks:
        score = 0
        for i in sector_data.index:
            sector_row = sector_data.loc[i]
            company_data = [float(item) for item in sector_row["smoothedList"][1:-1].split(', ')]
            start, change = calculate_grade(company_data)
            try:
                val = portfolio.loc[tick]
            except:continue
            val = val.loc[i]
            grade = "F"
            
            try:
                try:
                    val = float(val)
                except:
                    try:
                        val = int(val)
                    except:pass
                    
                if val > start:
                    grade = 'A+'
                    score += 9.9
                elif val > start - change:
                    grade = 'A'
                    score += 9
                elif val > start - (change * 2):
                    grade = 'A-'
                    score += 8.2
                elif val > start - (change * 3):
                    grade = 'B+'
                    score += 7.1
                elif val > start - (change * 4):
                    grade = 'B'
                    score += 6.3
                elif val > start - (change * 5):
                    grade = 'B-'
                    score += 5.5
                elif val > start - (change * 6):
                    grade = 'C+'
                    score += 4.6
                elif val > start - (change * 7):
                    grade = 'C'
                    score += 3.8 
                elif val > start - (change * 8):
                    grade = 'C-'
                    score += 3.2
                elif val > start - (change * 9):
                    grade = 'D+'
                    score += 2.3
                elif val > start - (change * 10):
                    grade = 'D'
                    score += 1.5
                elif val > start - (change * 11):
                    grade = 'D-'
                    score += 0.8
                else:
                    grade = 'F'
                    score -= 1.5
            except:pass
            
        
        #final_score = score * 2
        df_sum.loc[tick] = score


    data = yf.download(stocks, start = start_date, end = end_date, threads = False)
    data = data.loc[:,('Adj Close', slice(None))]
    data.columns = stocks
    print(data)

    df_diff = pd.DataFrame(index=stocks, columns=['1 day', '1 week', '1 month', '3 months', '6 months', '1 year', '3 years', '5 years', 'Ten years'])
    for tick in stocks:
        day = data[tick].pct_change(periods=1)
        week = data[tick].pct_change(periods=7)
        month = data[tick].pct_change(periods=21)
        three_month = data[tick].pct_change(periods=63)
        six_month = data[tick].pct_change(periods=126)
        year = data[tick].pct_change(periods=252)
        three_year = data[tick].pct_change(periods=252*3)
        five_yr = data[tick].pct_change(periods=252*5)
        ten_yr = ((data[tick].iloc[-1] - data[tick].iloc[0]) / data[tick].iloc[0])
        print(three_year)
        print(five_yr)
        print(ten_yr)
        try:
            day, week, month, three_month, six_month, year, three_year, five_yr = day.dropna()[0], week.dropna()[0], month.dropna()[0], three_month.dropna()[0], six_month.dropna()[0], year.dropna()[0], three_year.dropna()[0], five_yr.dropna()[0]
            df_diff.loc[tick] = day, week, month, three_month, six_month, year, three_year, five_yr, ten_yr
        except:pass
        '''try:
            day, week, month, three_month, six_month, year, three_year = day.dropna(), week.dropna(), month.dropna(), three_month.dropna(), six_month.dropna(), year.dropna(), three_year.dropna()
            df_diff.loc[tick] = day, week, month, three_month, six_month, year, three_year
        except:
            try:
                day, week, month, three_month, six_month, year = day.dropna(), week.dropna(), month.dropna(), three_month.dropna(), six_month.dropna(), year.dropna()
                df_diff.loc[tick] = day, week, month, three_month, six_month, year, '-'
            except: pass'''
        
    df_sum = df_sum.sort_values(by="Score", ascending=False)
    df = pd.concat([df_sum, df_diff], axis=1)
    df = df[df['1 day'].notna()]
    df = df[df['Score'] != 0]
    df.to_csv(f"tick_score_{sector}_2010.csv")



aplus = df[df['Score'] > 65]
print(aplus)

#grade_metrics_a
'''
df_grade = pd.read_csv("grade_metrics.csv", index_col=0)
print(df_grade.iloc[:, : 12])
print("\n")
print(df_grade.iloc[:, -4:])
print("\n")
df_grade = pd.read_csv("grade_metrics_a.csv", index_col=0)
print(df_grade.iloc[:, : 12])
print("\n")
print(df_grade.iloc[:, -4:])
print("\n")
'''